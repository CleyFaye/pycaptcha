"""pycaptcha package"""
from .recaptcha import check as recaptcha_check
